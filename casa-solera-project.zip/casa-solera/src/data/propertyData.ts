export interface GalleryImage {
  src: string;
  alt: string;
  label: string;
  caption: string;
}

export interface Suite {
  id: string;
  name: string;
  kicker: string;
  tagline: string;
  nightlyRate: number;
  platformRate: number;
  sqft: number;
  maxGuests: number;
  bedding: string;
  exposure: string;
  description: string;
  includedFacilities: string[];
  gallery: GalleryImage[];
}

export interface BenefitItem {
  id: string;
  index: string;
  title: string;
  description: string;
  metric: string;
  span: 'wide' | 'standard';
}

export interface FacilityDomain {
  id: string;
  index: string;
  title: string;
  summary: string;
  image: GalleryImage;
  items: {
    name: string;
    detail: string;
  }[];
}

export interface StayPlan {
  id: string;
  name: string;
  nightsLabel: string;
  minNights: number;
  discountPercent: number;
  badgeText: string;
  description: string;
  perks: string[];
  idealFor: string;
}

export interface ExperienceAddOn {
  id: string;
  name: string;
  price: number;
  unit: string;
  description: string;
}

export interface GuestReview {
  id: string;
  name: string;
  role: string;
  stayContext: string;
  quote: string;
}

export const IMAGES = {
  heroCourtyard: '/src/assets/images/hero_courtyard_villa_1794985259362.jpg',
  courtyardMaster: '/src/assets/images/suite_courtyard_master_1794985261340.jpg',
  terracottaLoft: '/src/assets/images/suite_terracotta_loft_1794985261040.jpg',
  oliveCasita: '/src/assets/images/suite_olive_casita_1794985262329.jpg',
  plungePool: '/src/assets/images/facility_plunge_pool_1794985263554.jpg',
  artisanKitchen: '/src/assets/images/facility_artisan_kitchen_1794985262192.jpg',
  claySpa: '/src/assets/images/facility_clay_spa_1794985265029.jpg',
};

export const HERO_METRICS = [
  { value: '4.98 / 5.0', label: 'Across 184 direct guest stays' },
  { value: '0% Service Fee', label: 'Save 14% vs. third-party platforms' },
  { value: '100% Solar', label: 'Off-grid wellness & rainwater estate' },
  { value: '2:00 PM', label: 'Complimentary late checkout included' },
];

export const DIRECT_BENEFITS: BenefitItem[] = [
  {
    id: 'zero-fees',
    index: '01',
    title: 'Zero Listing Platform Fees',
    description:
      'Third-party rental marketplaces quietly add 14% to 17% guest service fees at checkout. Booking direct removes every intermediary surcharge, keeping your budget focused on your stay.',
    metric: 'Avg. $210 saved per 3-night stay',
    span: 'wide',
  },
  {
    id: 'local-provisions',
    index: '02',
    title: 'Artisanal Harvest Welcome Basket',
    description:
      'Every direct reservation arrives to single-estate Ojai olive oil, sourdough from our village baker, fresh citrus, and locally roasted coffee beans.',
    metric: 'Included on all direct bookings',
    span: 'standard',
  },
  {
    id: 'late-checkout',
    index: '03',
    title: 'Unhurried 2:00 PM Departure',
    description:
      'Skip the 10:00 AM rush. Direct guests enjoy guaranteed late afternoon checkout and priority early bag drop from noon.',
    metric: '+4 hours in residence',
    span: 'standard',
  },
  {
    id: 'thermal-access',
    index: '04',
    title: 'Private Thermal & Plunge Scheduling',
    description:
      'Reserve exclusive dusk hours at the heated saltwater plunge pool and cedar barrel sauna directly with our estate host before arrival.',
    metric: '88°F year-round mineral water',
    span: 'wide',
  },
];

export const SUITES: Suite[] = [
  {
    id: 'courtyard-master',
    name: 'The Courtyard Master',
    kicker: 'Ground-Level Sanctuary · South Wing',
    tagline: 'Arched limestone doorway opening onto sunlit olive terraces.',
    nightlyRate: 410,
    platformRate: 476,
    sqft: 680,
    maxGuests: 2,
    bedding: '1 California King · Belgian Linen',
    exposure: 'Private South Courtyard',
    description:
      'Hand-troweled limewash walls, exposed white oak ceiling rafters, and an arched timber doorway that connects the bedroom directly to the courtyard fountain.',
    includedFacilities: [
      'Private tadelakt soaking tub & brass rain shower',
      'Direct step-out access to travertine courtyard patio',
      '1 Gbps fiber Wi-Fi & oak writing desk',
      'La Marzocco espresso bar & herbal tea station',
    ],
    gallery: [
      {
        src: IMAGES.courtyardMaster,
        alt: 'The Courtyard Master bedroom with limewash walls and terracotta linen throw',
        label: 'Master Bedroom',
        caption: 'Hand-troweled beige limewash plaster with Belgian oatmeal linen and arched patio doorway.',
      },
      {
        src: IMAGES.claySpa,
        alt: 'Private tadelakt clay plaster spa bathroom with stone soaking tub',
        label: 'Tadelakt Clay Bath',
        caption: 'En-suite waterproof tadelakt bathroom featuring a hand-carved basalt soaking vessel.',
      },
      {
        src: IMAGES.heroCourtyard,
        alt: 'Sunlit limestone courtyard with olive trees and terracotta planters',
        label: 'Courtyard Terrace',
        caption: 'Direct morning access to the shaded pergola lounge and courtyard stone fountain.',
      },
      {
        src: IMAGES.plungePool,
        alt: 'Travertine saltwater plunge pool overlooking desert ridges',
        label: 'Thermal Terrace',
        caption: 'Heated saltwater plunge terrace steps from the south wing.',
      },
    ],
  },
  {
    id: 'terracotta-loft',
    name: 'The Terracotta Loft',
    kicker: 'Double-Height Residence · Upper Ridge',
    tagline: 'Venetian clay plaster, travertine hearth, and panoramic valley glass.',
    nightlyRate: 520,
    platformRate: 604,
    sqft: 940,
    maxGuests: 4,
    bedding: '1 King Mezzanine + 1 Daybed',
    exposure: '270° Ridge & Sunset Views',
    description:
      'Designed for couples, writers, and small groups seeking open space. Features a custom travertine wood-burning hearth and full chef kitchen.',
    includedFacilities: [
      'Full monolithic travertine chef kitchen & copper cookware',
      'Wood-burning travertine fireplace & curated vinyl library',
      'Private upper ridge sun deck with terracotta loungers',
      'Acoustic mezzanine studio workspace',
    ],
    gallery: [
      {
        src: IMAGES.terracottaLoft,
        alt: 'Double-height Terracotta Loft living room with travertine fireplace and steel windows',
        label: 'Loft Living & Hearth',
        caption: 'Double-height Venetian plaster living space anchored by a honed travertine hearth.',
      },
      {
        src: IMAGES.artisanKitchen,
        alt: 'Architectural chef kitchen with monolithic travertine island and oak cabinetry',
        label: 'Artisan Kitchen',
        caption: 'Full culinary kitchen with monolithic stone island, copper pans, and espresso machine.',
      },
      {
        src: IMAGES.plungePool,
        alt: 'Sunset view from the saltwater plunge terrace',
        label: 'Ridge Plunge Deck',
        caption: 'Sunset-facing travertine terrace with sunken linen loungers.',
      },
      {
        src: IMAGES.claySpa,
        alt: 'Warm plaster spa bath with skylight',
        label: 'Skylit Bathhouse',
        caption: 'Overhead natural skylight illuminating brushed brass fixtures and stone floors.',
      },
    ],
  },
  {
    id: 'olive-casita',
    name: 'The Olive Grove Casita',
    kicker: 'Detached Garden Pavilion · West Orchard',
    tagline: 'Standalone privacy framed by century-old olive trees.',
    nightlyRate: 365,
    platformRate: 424,
    sqft: 540,
    maxGuests: 2,
    bedding: '1 King · Stone-Washed Linen',
    exposure: 'Detached Orchard Garden',
    description:
      'Tucked quietly beneath the western olive orchard with zero shared walls. Reclaimed barnwood shutters open directly onto wild rosemary pathways.',
    includedFacilities: [
      'Completely detached private entrance & orchard hammock',
      'Microcement radiant-heated floors & terracotta pendants',
      'Outdoor cedar rain shower surrounded by desert sage',
      'Dedicated EV Level 2 charging bay nearby',
    ],
    gallery: [
      {
        src: IMAGES.oliveCasita,
        alt: 'Olive Grove Casita bedroom with timber windows looking onto olive trees',
        label: 'Orchard Bedroom',
        caption: 'Reclaimed timber casement windows framing the quiet morning olive orchard.',
      },
      {
        src: IMAGES.heroCourtyard,
        alt: 'Stone pathway leading from the olive casita to the main courtyard',
        label: 'Garden Walkway',
        caption: 'Travertine garden promenade linking the orchard casita to the central pergola.',
      },
      {
        src: IMAGES.claySpa,
        alt: 'Private stone and clay bathroom',
        label: 'En-Suite Spa',
        caption: 'Hand-plastered bath sanctuary stocked with botanical Ojai apothecary goods.',
      },
      {
        src: IMAGES.artisanKitchen,
        alt: 'Shared estate culinary pavilion accessible to all guests',
        label: 'Culinary Pavilion',
        caption: 'Full access to the main house chef kitchen and espresso bar.',
      },
    ],
  },
  {
    id: 'full-estate',
    name: 'Full Estate Buyout',
    kicker: 'All 3 Residences · Private Compound',
    tagline: 'Exclusive keys to the entire 2.4-acre sanctuary for retreats and gatherings.',
    nightlyRate: 1180,
    platformRate: 1370,
    sqft: 2850,
    maxGuests: 8,
    bedding: '3 King Suites + Loft Daybed',
    exposure: '2.4-Acre Private Grounds',
    description:
      'Reserve every suite, courtyard, thermal plunge pool, outdoor wood-fired oven, and orchard dining table for intimate creative offsites or family gatherings.',
    includedFacilities: [
      'Exclusive private use of plunge pool, sauna & chef kitchen',
      'Outdoor 10-seat limestone pergola dining table',
      'Dedicated local estate host & pre-arrival pantry stocking',
      'Complimentary private chef welcome dinner for 8',
    ],
    gallery: [
      {
        src: IMAGES.heroCourtyard,
        alt: 'Full estate limestone courtyard and wooden pergola at golden hour',
        label: 'Central Courtyard',
        caption: 'The central limestone gathering courtyard for long golden-hour dinners.',
      },
      {
        src: IMAGES.plungePool,
        alt: 'Private heated saltwater plunge pool terrace',
        label: 'Private Plunge Terrace',
        caption: 'Unshared access to the heated saltwater pool and mountain horizon deck.',
      },
      {
        src: IMAGES.artisanKitchen,
        alt: 'Estate culinary chef kitchen with travertine island',
        label: 'Chef Kitchen',
        caption: 'Commercial-grade gas range, copper cookware, and espresso bar for group cooking.',
      },
      {
        src: IMAGES.terracottaLoft,
        alt: 'Terracotta Loft main salon',
        label: 'Upper Salon',
        caption: 'Evening gathering room around the travertine wood-burning hearth.',
      },
      {
        src: IMAGES.courtyardMaster,
        alt: 'Courtyard Master Suite',
        label: 'South Master',
        caption: 'Primary king suite opening directly onto the courtyard.',
      },
      {
        src: IMAGES.oliveCasita,
        alt: 'Olive Grove Casita',
        label: 'Orchard Casita',
        caption: 'Detached orchard suite ideal for guests seeking extra quiet.',
      },
    ],
  },
];

export const FACILITY_DOMAINS: FacilityDomain[] = [
  {
    id: 'wellness',
    index: '01',
    title: 'Thermal Pool & Clay Spa',
    summary:
      'Restorative hydrotherapy built around mineral water, natural stone, and desert silence.',
    image: {
      src: IMAGES.plungePool,
      alt: 'Heated travertine saltwater plunge pool with mountain backdrop',
      label: 'Thermal Terrace',
      caption: 'Heated to 88°F year-round with low-salinity mineral filtration.',
    },
    items: [
      { name: 'Saltwater Plunge Pool', detail: 'Heated 88°F · Travertine coping · Sunset terrace' },
      { name: 'Cedar Barrel Sauna', detail: 'Finnish dry heat up to 190°F · Eucalyptus infusions' },
      { name: 'Tadelakt Soaking Tubs', detail: 'Hand-carved basalt basins · Botanical bath salts' },
      { name: 'Outdoor Sage Shower', detail: 'Warm brass rain head · Wild desert garden enclosure' },
    ],
  },
  {
    id: 'culinary',
    index: '02',
    title: 'Culinary & Hearth',
    summary:
      'A welcoming kitchen built for slow breakfasts, wood-fired flatbreads, and local natural wine.',
    image: {
      src: IMAGES.artisanKitchen,
      alt: 'Artisan chef kitchen with monolithic travertine island and copper pans',
      label: 'Chef Kitchen',
      caption: 'Stocked with local stoneware, copper cookware, and single-origin espresso.',
    },
    items: [
      { name: 'Monolithic Travertine Island', detail: '36" dual-fuel range · Mauviel copper cookware' },
      { name: 'La Marzocco Espresso Bar', detail: 'Freshly roasted local beans · Oat & whole milk stocked' },
      { name: 'Wood-Fired Courtyard Oven', detail: 'Seasoned oak firewood · Cast-iron pizza peels' },
      { name: 'Walk-In Wine & Pantry Cellar', detail: 'Santa Ynez & Ojai natural wines · Estate olive oil' },
    ],
  },
  {
    id: 'connectivity',
    index: '03',
    title: 'Work & Acoustic Calm',
    summary:
      'Effortless remote-work infrastructure concealed beneath warm natural plaster and timber.',
    image: {
      src: IMAGES.terracottaLoft,
      alt: 'Quiet sunlit loft lounge and acoustic workspace',
      label: 'Ridge Study',
      caption: 'High-speed symmetrical fiber across every suite and outdoor pergola.',
    },
    items: [
      { name: '1 Gbps Symmetrical Fiber', detail: 'Enterprise mesh across all suites, casita & pool deck' },
      { name: 'Solid White Oak Desks', detail: 'Ergonomic seating · Concealed USB-C power hubs' },
      { name: 'Acoustic Limewash Walls', detail: '22-inch insulated plaster masonry for silent calls' },
      { name: 'Curated Library & Vinyl', detail: '200+ architecture monographs & tube-amp turntable' },
    ],
  },
  {
    id: 'grounds',
    index: '04',
    title: 'Grounds & Concierge',
    summary:
      '2.4 private acres designed for effortless arrivals, electric mobility, and local discovery.',
    image: {
      src: IMAGES.heroCourtyard,
      alt: 'Courtyard pergola, olive trees, and gravel driveway',
      label: '2.4-Acre Grounds',
      caption: 'Gated olive-grove sanctuary 6 minutes from downtown Ojai.',
    },
    items: [
      { name: 'Dual EV Level 2 Chargers', detail: 'Universal J1772 & NACS adapters · Solar-powered' },
      { name: 'Private Ceramicist Access', detail: 'Kiln studio tours & wheel-throwing sessions nearby' },
      { name: 'Keyless Encrypted Entry', detail: 'Custom arrival code sent 48 hours prior' },
      { name: 'Dedicated Estate Host', detail: 'Same-day chef, masseuse & trail reservations' },
    ],
  },
];

export const STAY_PLANS: StayPlan[] = [
  {
    id: 'weekend',
    name: 'Weekend Sanctuary',
    nightsLabel: '2 to 6 Nights',
    minNights: 2,
    discountPercent: 0,
    badgeText: 'Base Direct Rate · 0% Platform Fee',
    description:
      'Ideal for restorative Friday to Monday escapes with every direct-booking perk unlocked.',
    perks: [
      '0% third-party service fee (14% instant savings)',
      'Complimentary 2:00 PM late checkout',
      'Artisanal Ojai harvest welcome basket',
      'Full thermal pool & sauna access',
    ],
    idealFor: 'Couples, weekend resets & celebrations',
  },
  {
    id: 'slow-week',
    name: 'Slow Living Week',
    nightsLabel: '7 to 13 Nights',
    minNights: 7,
    discountPercent: 15,
    badgeText: '15% Weekly Reduction Applied',
    description:
      'Settle into the valley rhythm with mid-week housekeeping, replenished pantry staples, and weekly savings.',
    perks: [
      '15% off direct nightly suite rates',
      'Mid-stay fresh Belgian linen & towel refresh',
      '2 complimentary private sauna twilight bookings',
      'Dedicated pantry pre-stocking before arrival',
    ],
    idealFor: 'Remote founders, writers & unhurried travelers',
  },
  {
    id: 'sabbatical',
    name: 'Creative Sabbatical',
    nightsLabel: '14+ Nights',
    minNights: 14,
    discountPercent: 25,
    badgeText: '25% Sabbatical Reduction Applied',
    description:
      'Designed for extended deep work, creative residencies, or seasonal retreats with bespoke concierge support.',
    perks: [
      '25% off direct nightly suite rates',
      'Weekly housekeeping & organic farm box delivery',
      'Private local ceramicist studio pass included',
      'Flexible date modification up to 7 days prior',
    ],
    idealFor: 'Extended residencies, authors & design teams',
  },
];

export const EXPERIENCE_ADDONS: ExperienceAddOn[] = [
  {
    id: 'chef-dinner',
    name: 'Private Fireside Chef Dinner',
    price: 290,
    unit: 'for two',
    description: 'Four-course seasonal Ojai tasting menu cooked over our courtyard oak hearth.',
  },
  {
    id: 'breathwork-sauna',
    name: 'Guided Breathwork & Thermal Contrast',
    price: 165,
    unit: 'per session',
    description: '75-minute morning breathwork, cedar sauna heat, and cold mineral immersion.',
  },
  {
    id: 'ceramic-workshop',
    name: 'Private Terracotta Pottery Session',
    price: 195,
    unit: 'for two',
    description: 'Two-hour wheel and hand-building studio session with local Ojai ceramicist.',
  },
  {
    id: 'chauffeur',
    name: 'SBA Airport Chauffeur Transfer',
    price: 140,
    unit: 'each way',
    description: 'Private electric SUV transfer from Santa Barbara Municipal Airport (45 mins).',
  },
];

export const GUEST_REVIEWS: GuestReview[] = [
  {
    id: 'r1',
    name: 'Elena Vance & Marcus Holt',
    role: 'Architectural Principals, Studio Vance',
    stayContext: 'Terracotta Loft · 7-Night Slow Living Week',
    quote:
      'We booked on major platforms for years until discovering Casa Solera direct. Saving $480 in platform fees paid for our private courtyard dinner, and the quiet atmosphere let us finish an entire brief before noon each day.',
  },
  {
    id: 'r2',
    name: 'Claire Takahashi',
    role: 'Editorial Director & Ceramicist',
    stayContext: 'Courtyard Master · 4-Night Sanctuary',
    quote:
      'Every detail, from the unlacquered brass rain shower to the cool limewash walls, feels intentional rather than staged. Watching sunset hit the terracotta planters with no checkout rush until 2 PM was restorative.',
  },
  {
    id: 'r3',
    name: 'David & Priya Kapoor',
    role: 'Founders, Hearthstone Collective',
    stayContext: 'Full Estate Buyout · 3-Night Offsite',
    quote:
      'Hosting our six-person leadership retreat here replaced sterile hotel conference rooms with wood-fired dinners under the pergola. The fiber internet never dropped once across eight devices.',
  },
];

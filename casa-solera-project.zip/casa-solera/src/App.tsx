import { useMemo, useState } from 'react';
import { MotionConfig } from 'motion/react';
import { EXPERIENCE_ADDONS, STAY_PLANS, SUITES } from './data/propertyData';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { MotiveAndBenefitsSection } from './components/MotiveAndBenefitsSection';
import { SuitesGallerySection } from './components/SuitesGallerySection';
import { FacilitiesSection } from './components/FacilitiesSection';
import { PlansAndPricingSection } from './components/PlansAndPricingSection';
import { TestimonialsAndBookingSection } from './components/TestimonialsAndBookingSection';
import { Footer } from './components/Footer';

function addDaysISO(dateStr: string, days: number): string {
  const date = new Date(`${dateStr}T12:00:00`);
  if (Number.isNaN(date.getTime())) return dateStr;
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

function diffNights(checkIn: string, checkOut: string): number {
  const start = new Date(`${checkIn}T12:00:00`);
  const end = new Date(`${checkOut}T12:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 2;
  const diff = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(1, diff);
}

export default function App() {
  const [checkIn, setCheckIn] = useState('2026-12-04');
  const [checkOut, setCheckOut] = useState('2026-12-07');
  const [selectedSuiteId, setSelectedSuiteId] = useState<string>(SUITES[0].id);
  const [guests, setGuests] = useState<number>(2);
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [formHighlightKey, setFormHighlightKey] = useState<number>(0);

  const nights = useMemo(() => diffNights(checkIn, checkOut), [checkIn, checkOut]);

  const activePlan = useMemo(() => {
    if (nights >= 14) return STAY_PLANS[2];
    if (nights >= 7) return STAY_PLANS[1];
    return STAY_PLANS[0];
  }, [nights]);

  const activeSuite = useMemo(
    () => SUITES.find((s) => s.id === selectedSuiteId) || SUITES[0],
    [selectedSuiteId]
  );

  const { estimatedTotal, directSavings } = useMemo(() => {
    const baseSubtotal = activeSuite.nightlyRate * nights;
    const discountAmount = Math.round(baseSubtotal * (activePlan.discountPercent / 100));
    const addOnsSum = EXPERIENCE_ADDONS.filter((a) => selectedAddOns.includes(a.id)).reduce(
      (sum, item) => sum + item.price,
      0
    );
    const total = baseSubtotal - discountAmount + addOnsSum;
    const platformTotal = activeSuite.platformRate * nights + addOnsSum;
    return {
      estimatedTotal: total,
      directSavings: Math.max(0, platformTotal - total),
    };
  }, [activeSuite, activePlan, nights, selectedAddOns]);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollToBookingForm = () => {
    setFormHighlightKey((prev) => prev + 1);
    const formEl = document.getElementById('booking-form');
    if (formEl) {
      formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      window.setTimeout(() => {
        const firstInput = document.getElementById('guest-name') as HTMLInputElement | null;
        if (firstInput) {
          firstInput.focus({ preventScroll: true });
        }
      }, 450);
    }
  };

  const handleCheckInChange = (nextCheckIn: string) => {
    setCheckIn(nextCheckIn);
    if (diffNights(nextCheckIn, checkOut) < 2 || nextCheckIn >= checkOut) {
      setCheckOut(addDaysISO(nextCheckIn, 3));
    }
  };

  const handleCheckOutChange = (nextCheckOut: string) => {
    if (nextCheckOut <= checkIn) {
      setCheckOut(addDaysISO(checkIn, 2));
    } else {
      setCheckOut(nextCheckOut);
    }
  };

  const handleSuiteChange = (suiteId: string) => {
    setSelectedSuiteId(suiteId);
    const suite = SUITES.find((s) => s.id === suiteId);
    if (suite && guests > suite.maxGuests) {
      setGuests(suite.maxGuests);
    }
  };

  const handleSelectSuiteAndScroll = (suiteId: string) => {
    handleSuiteChange(suiteId);
    scrollToBookingForm();
  };

  const handleSelectPlan = (planId: string) => {
    const plan = STAY_PLANS.find((p) => p.id === planId);
    if (plan) {
      const targetNights = plan.id === 'weekend' ? 3 : plan.minNights;
      setCheckOut(addDaysISO(checkIn, targetNights));
    }
    scrollToBookingForm();
  };

  const handleToggleAddOn = (addonId: string) => {
    setSelectedAddOns((prev) =>
      prev.includes(addonId) ? prev.filter((id) => id !== addonId) : [...prev, addonId]
    );
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#F6F2EB] text-[#1E1814] flex flex-col">
        <Header onReserveClick={scrollToBookingForm} />

        <main className="flex-1">
          <HeroSection
            checkIn={checkIn}
            checkOut={checkOut}
            selectedSuiteId={selectedSuiteId}
            guests={guests}
            nights={nights}
            estimatedTotal={estimatedTotal}
            directSavings={directSavings}
            onCheckInChange={handleCheckInChange}
            onCheckOutChange={handleCheckOutChange}
            onSuiteChange={handleSuiteChange}
            onGuestsChange={setGuests}
            onJumpToBooking={scrollToBookingForm}
          />

          <MotiveAndBenefitsSection onExploreSuites={() => scrollToSection('suites')} />

          <SuitesGallerySection
            selectedSuiteId={selectedSuiteId}
            onSelectSuiteForBooking={handleSelectSuiteAndScroll}
          />

          <FacilitiesSection onReserveClick={scrollToBookingForm} />

          <PlansAndPricingSection
            activePlanId={activePlan.id}
            selectedAddOns={selectedAddOns}
            onSelectPlan={handleSelectPlan}
            onToggleAddOn={handleToggleAddOn}
          />

          <TestimonialsAndBookingSection
            checkIn={checkIn}
            checkOut={checkOut}
            selectedSuiteId={selectedSuiteId}
            guests={guests}
            nights={nights}
            selectedAddOns={selectedAddOns}
            formHighlightKey={formHighlightKey}
            onCheckInChange={handleCheckInChange}
            onCheckOutChange={handleCheckOutChange}
            onSuiteChange={handleSuiteChange}
            onGuestsChange={setGuests}
            onToggleAddOn={handleToggleAddOn}
          />
        </main>

        <Footer />
      </div>
    </MotionConfig>
  );
}

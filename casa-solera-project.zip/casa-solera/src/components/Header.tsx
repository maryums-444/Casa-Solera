import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Menu, X } from 'lucide-react';

interface HeaderProps {
  onReserveClick: () => void;
}

const NAV_ITEMS = [
  { label: 'Our Motive', href: '#motive' },
  { label: 'Suites', href: '#suites' },
  { label: 'Facilities', href: '#facilities' },
  { label: 'Stay Plans', href: '#plans' },
];

export function Header({ onReserveClick }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#241E1A]/95 backdrop-blur-md border-b-2 border-[#B8472A] shadow-sm">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 h-18 flex items-center justify-between gap-8">
        {/* Zone 1: Prominent single-element brand wordmark */}
        <a
          href="#top"
          className="font-display text-2xl sm:text-[28px] font-semibold tracking-tight text-[#F6F2EB] hover:text-[#F0DFCE] transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#D15435]"
        >
          Casa Solera
        </a>

        {/* Zone 2: 4 clean single-line text navigation links */}
        <nav
          aria-label="Primary navigation"
          className="hidden md:flex items-center gap-8 text-sm font-medium text-[#DFD5C6]"
        >
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="relative py-1.5 hover:text-white transition-colors duration-150 whitespace-nowrap shrink-0 after:content-[''] after:absolute after:left-0 after:bottom-0 after:w-full after:h-[2px] after:bg-[#D15435] after:scale-x-0 hover:after:scale-x-100 after:transition-transform after:duration-200 after:origin-left focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#D15435]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Prominent terracotta primary action + mobile menu toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onReserveClick}
            className="px-5 py-2.5 text-sm font-medium text-white bg-[#B8472A] hover:bg-[#D15435] active:scale-[0.98] rounded-lg shadow-xs transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
          >
            Reserve Stay
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
            className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg border border-[#473D35] text-[#F6F2EB] hover:bg-[#332B25] transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile navigation drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            aria-label="Mobile navigation"
            className="md:hidden border-t border-[#3E342D] bg-[#241E1A] px-5 py-4 flex flex-col gap-3"
          >
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={handleNavClick}
                className="py-2 text-base font-medium text-[#F6F2EB] hover:text-[#E58D73] border-b border-[#382F29] last:border-b-0 transition-colors"
              >
                {item.label}
              </a>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}

import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ChevronLeft, ChevronRight, Expand, Check, X } from 'lucide-react';
import { GalleryImage, SUITES, Suite } from '../data/propertyData';
import { ResilientImage } from './ResilientImage';

interface SuitesGallerySectionProps {
  selectedSuiteId: string;
  onSelectSuiteForBooking: (suiteId: string) => void;
}

interface LightboxState {
  suiteName: string;
  suiteId: string;
  images: GalleryImage[];
  index: number;
}

function SuiteGalleryCard({
  suite,
  isSelected,
  onSelectSuite,
  onOpenLightbox,
}: {
  suite: Suite;
  isSelected: boolean;
  onSelectSuite: (id: string) => void;
  onOpenLightbox: (suite: Suite, index: number) => void;
}) {
  const [activeIndex, setActiveIndex] = useState(0);
  const currentImage = suite.gallery[activeIndex] || suite.gallery[0];
  const savingsPerNight = suite.platformRate - suite.nightlyRate;

  const handlePrev = () => {
    setActiveIndex((prev) => (prev === 0 ? suite.gallery.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev === suite.gallery.length - 1 ? 0 : prev + 1));
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.1 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className={`rounded-xl border bg-[#ECE5D8]/65 transition-all duration-200 overflow-hidden ${
        isSelected ? 'border-[#B8472A] shadow-sm' : 'border-[#D5C9B6] hover:border-[#C2B097]'
      }`}
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
        {/* Left: Interactive Multi-Image Gallery */}
        <div className="lg:col-span-7 p-4 sm:p-6 flex flex-col gap-3 border-b lg:border-b-0 lg:border-r border-[#D5C9B6]">
          <div className="relative aspect-[4/3] w-full rounded-lg overflow-hidden bg-[#E2D9C8] border border-[#D5C9B6] group">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentImage.src + activeIndex}
                initial={{ opacity: 0.35, scale: 1.01 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0.35 }}
                transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
                className="w-full h-full"
              >
                <ResilientImage
                  src={currentImage.src}
                  alt={currentImage.alt}
                  fallbackTitle={`${suite.name}: ${currentImage.label}`}
                  className="w-full h-full object-cover"
                />
              </motion.div>
            </AnimatePresence>

            {/* Scrim + Caption Bar */}
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-4 flex items-end justify-between gap-4">
              <div className="text-white">
                <p className="text-xs font-medium text-[#F3B19D]">
                  {currentImage.label}
                  <span aria-hidden="true" className="mx-1.5 text-white/70">
                    ·
                  </span>
                  <span className="tabular-nums text-white/90">
                    {activeIndex + 1} / {suite.gallery.length}
                  </span>
                </p>
                <p className="text-xs sm:text-sm text-white/95 mt-0.5 line-clamp-1">
                  {currentImage.caption}
                </p>
              </div>

              <button
                type="button"
                onClick={() => onOpenLightbox(suite, activeIndex)}
                aria-label={`Expand gallery for ${suite.name}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-black/55 hover:bg-[#B8472A] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Expand className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Expand</span>
              </button>
            </div>

            {/* Gallery Prev / Next Controls */}
            <button
              type="button"
              onClick={handlePrev}
              aria-label={`Previous photo of ${suite.name}`}
              className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#F6F2EB]/90 hover:bg-[#F6F2EB] text-[#1E1814] border border-[#D5C9B6] flex items-center justify-center transition-transform hover:scale-105 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#B8472A]"
            >
              <ChevronLeft className="w-5 h-5" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={handleNext}
              aria-label={`Next photo of ${suite.name}`}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-[#F6F2EB]/90 hover:bg-[#F6F2EB] text-[#1E1814] border border-[#D5C9B6] flex items-center justify-center transition-transform hover:scale-105 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#B8472A]"
            >
              <ChevronRight className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          {/* Clickable Thumbnail Strip */}
          <div
            className="grid grid-cols-4 sm:grid-cols-6 gap-2.5"
            role="tablist"
            aria-label={`${suite.name} gallery thumbnails`}
          >
            {suite.gallery.map((img, idx) => {
              const active = idx === activeIndex;
              return (
                <button
                  key={`${suite.id}-thumb-${idx}`}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  aria-label={`View ${img.label}`}
                  onClick={() => setActiveIndex(idx)}
                  className={`relative aspect-[4/3] rounded-md overflow-hidden border transition-all duration-150 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B8472A] ${
                    active
                      ? 'border-[#B8472A] ring-2 ring-[#B8472A]/35 scale-[1.02]'
                      : 'border-[#D5C9B6] opacity-75 hover:opacity-100'
                  }`}
                >
                  <ResilientImage
                    src={img.src}
                    alt={img.label}
                    fallbackTitle={img.label}
                    className="w-full h-full object-cover"
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Structured Room Specs, Facilities & Direct Booking CTA */}
        <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-2">
              {suite.kicker}
            </p>
            <h3 className="font-display text-3xl sm:text-[34px] font-semibold text-[#1E1814] leading-tight mb-2">
              {suite.name}
            </h3>
            <p className="text-sm font-medium text-[#1E1814] mb-3">{suite.tagline}</p>
            <p className="text-sm text-[#5C5046] leading-relaxed mb-6">{suite.description}</p>

            {/* Unboxed Metadata Specification Grid */}
            <dl className="grid grid-cols-2 gap-x-4 gap-y-3 py-4 border-y border-[#D5C9B6] text-xs mb-6">
              <div>
                <dt className="text-[#5C5046]">Interior Area</dt>
                <dd className="font-medium text-[#1E1814] tabular-nums mt-0.5">
                  {suite.sqft.toLocaleString()} sq ft
                </dd>
              </div>
              <div>
                <dt className="text-[#5C5046]">Capacity</dt>
                <dd className="font-medium text-[#1E1814] tabular-nums mt-0.5">
                  Up to {suite.maxGuests} Guests
                </dd>
              </div>
              <div>
                <dt className="text-[#5C5046]">Sleeping</dt>
                <dd className="font-medium text-[#1E1814] mt-0.5">{suite.bedding}</dd>
              </div>
              <div>
                <dt className="text-[#5C5046]">Orientation</dt>
                <dd className="font-medium text-[#1E1814] mt-0.5">{suite.exposure}</dd>
              </div>
            </dl>

            {/* Suite-Specific Included Facilities */}
            <div className="mb-6">
              <p className="text-xs font-semibold text-[#5C5046] mb-2.5">
                Included Suite Facilities
              </p>
              <ul className="space-y-2">
                {suite.includedFacilities.map((facility) => (
                  <li key={facility} className="flex items-start gap-2.5 text-sm text-[#1E1814]">
                    <Check
                      className="w-4 h-4 text-[#B8472A] shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                    <span>{facility}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Transparent Pricing & Conversion Action */}
          <div className="pt-5 border-t border-[#D5C9B6] flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="font-display text-3xl font-semibold text-[#1E1814] tabular-nums">
                  ${suite.nightlyRate}
                </span>
                <span className="text-xs text-[#5C5046]">/ night direct</span>
                <span className="text-xs text-[#5C5046] line-through tabular-nums">
                  ${suite.platformRate}
                </span>
              </div>
              <p className="text-xs font-semibold text-[#B8472A] tabular-nums mt-0.5">
                Save ${savingsPerNight}/night by booking direct
              </p>
            </div>

            <button
              type="button"
              onClick={() => onSelectSuite(suite.id)}
              className={`px-5 py-3 text-sm font-medium rounded-lg transition-all duration-150 active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B8472A] ${
                isSelected
                  ? 'bg-[#241E1A] text-white hover:bg-[#3A312B]'
                  : 'bg-[#B8472A] text-white hover:bg-[#96361D]'
              }`}
            >
              {isSelected ? 'Selected · Go to Form' : 'Select Suite'}
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );
}

export function SuitesGallerySection({
  selectedSuiteId,
  onSelectSuiteForBooking,
}: SuitesGallerySectionProps) {
  const [filterId, setFilterId] = useState<string>('all');
  const [lightbox, setLightbox] = useState<LightboxState | null>(null);

  const visibleSuites =
    filterId === 'all' ? SUITES : SUITES.filter((suite) => suite.id === filterId);

  useEffect(() => {
    if (!lightbox) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setLightbox(null);
      } else if (e.key === 'ArrowLeft') {
        setLightbox((prev) =>
          prev
            ? {
                ...prev,
                index: prev.index === 0 ? prev.images.length - 1 : prev.index - 1,
              }
            : null
        );
      } else if (e.key === 'ArrowRight') {
        setLightbox((prev) =>
          prev
            ? {
                ...prev,
                index: prev.index === prev.images.length - 1 ? 0 : prev.index + 1,
              }
            : null
        );
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightbox]);

  return (
    <section id="suites" className="py-16 sm:py-24 border-b border-[#D5C9B6]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-2">
              Residences &amp; Galleries
            </p>
            <h2
              className="font-display text-4xl sm:text-5xl font-semibold text-[#1E1814] leading-[1.08] tracking-tight"
              style={{ textWrap: 'balance' }}
            >
              Three private suites, or the entire two-acre compound.
            </h2>
          </div>

          {/* Interactive Filter Bar */}
          <div
            role="tablist"
            aria-label="Filter suites"
            className="flex flex-wrap items-center gap-1 p-1 bg-[#ECE5D8] border border-[#D5C9B6] rounded-lg self-start lg:self-auto"
          >
            <button
              type="button"
              role="tab"
              aria-selected={filterId === 'all'}
              onClick={() => setFilterId('all')}
              className={`px-3.5 py-2 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                filterId === 'all'
                  ? 'bg-[#B8472A] text-white shadow-xs'
                  : 'text-[#5C5046] hover:text-[#1E1814]'
              }`}
            >
              All Suites (4)
            </button>
            {SUITES.map((suite) => (
              <button
                key={suite.id}
                type="button"
                role="tab"
                aria-selected={filterId === suite.id}
                onClick={() => setFilterId(suite.id)}
                className={`px-3.5 py-2 text-xs font-medium rounded-md transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  filterId === suite.id
                    ? 'bg-[#B8472A] text-white shadow-xs'
                    : 'text-[#5C5046] hover:text-[#1E1814]'
                }`}
              >
                {suite.name.replace('The ', '')}
              </button>
            ))}
          </div>
        </div>

        {/* Suite Showcase Stack */}
        <div className="space-y-8">
          {visibleSuites.map((suite) => (
            <SuiteGalleryCard
              key={suite.id}
              suite={suite}
              isSelected={selectedSuiteId === suite.id}
              onSelectSuite={onSelectSuiteForBooking}
              onOpenLightbox={(targetSuite, idx) =>
                setLightbox({
                  suiteName: targetSuite.name,
                  suiteId: targetSuite.id,
                  images: targetSuite.gallery,
                  index: idx,
                })
              }
            />
          ))}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            role="dialog"
            aria-modal="true"
            aria-label={`${lightbox.suiteName} photo gallery`}
            className="fixed inset-0 z-50 bg-[#1B1613]/95 backdrop-blur-sm flex flex-col justify-between p-4 sm:p-8"
          >
            <div className="max-w-6xl w-full mx-auto flex items-center justify-between gap-4 text-white">
              <div>
                <p className="font-display text-2xl font-semibold">{lightbox.suiteName}</p>
                <p className="text-xs text-white/75 tabular-nums">
                  {lightbox.images[lightbox.index].label} · {lightbox.index + 1} of{' '}
                  {lightbox.images.length}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const id = lightbox.suiteId;
                    setLightbox(null);
                    onSelectSuiteForBooking(id);
                  }}
                  className="px-4 py-2 text-xs font-medium text-white bg-[#B8472A] hover:bg-[#D15435] rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  Reserve This Suite
                </button>
                <button
                  type="button"
                  onClick={() => setLightbox(null)}
                  aria-label="Close gallery"
                  className="w-10 h-10 rounded-lg border border-white/20 text-white hover:bg-white/10 flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5" aria-hidden="true" />
                </button>
              </div>
            </div>

            <div className="max-w-5xl w-full mx-auto my-4 relative flex-1 min-h-0 flex items-center justify-center">
              <div className="relative w-full h-full max-h-[68vh] rounded-xl overflow-hidden border border-white/15 bg-[#241E1A]">
                <ResilientImage
                  src={lightbox.images[lightbox.index].src}
                  alt={lightbox.images[lightbox.index].alt}
                  fallbackTitle={lightbox.images[lightbox.index].label}
                  className="w-full h-full object-contain"
                />
              </div>

              <button
                type="button"
                onClick={() =>
                  setLightbox((prev) =>
                    prev
                      ? {
                          ...prev,
                          index: prev.index === 0 ? prev.images.length - 1 : prev.index - 1,
                        }
                      : null
                  )
                }
                aria-label="Previous image"
                className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/20 flex items-center justify-center cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" aria-hidden="true" />
              </button>
              <button
                type="button"
                onClick={() =>
                  setLightbox((prev) =>
                    prev
                      ? {
                          ...prev,
                          index: prev.index === prev.images.length - 1 ? 0 : prev.index + 1,
                        }
                      : null
                  )
                }
                aria-label="Next image"
                className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/20 flex items-center justify-center cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="max-w-5xl w-full mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <p className="text-sm text-white/85">{lightbox.images[lightbox.index].caption}</p>
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {lightbox.images.map((img, idx) => (
                  <button
                    key={`lb-thumb-${idx}`}
                    type="button"
                    onClick={() => setLightbox((prev) => (prev ? { ...prev, index: idx } : null))}
                    aria-label={`Jump to ${img.label}`}
                    className={`w-16 aspect-[4/3] rounded overflow-hidden border shrink-0 cursor-pointer ${
                      idx === lightbox.index
                        ? 'border-[#B8472A] ring-2 ring-[#B8472A]'
                        : 'border-white/20 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <ResilientImage
                      src={img.src}
                      alt={img.label}
                      fallbackTitle={img.label}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

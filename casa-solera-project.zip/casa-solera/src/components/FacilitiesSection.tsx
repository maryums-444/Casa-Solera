import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { FACILITY_DOMAINS } from '../data/propertyData';
import { ResilientImage } from './ResilientImage';

interface FacilitiesSectionProps {
  onReserveClick: () => void;
}

export function FacilitiesSection({ onReserveClick }: FacilitiesSectionProps) {
  const [activeDomainId, setActiveDomainId] = useState(FACILITY_DOMAINS[0].id);
  const activeDomain =
    FACILITY_DOMAINS.find((domain) => domain.id === activeDomainId) || FACILITY_DOMAINS[0];

  return (
    <section id="facilities" className="py-16 sm:py-24 border-b border-[#D5C9B6]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-2">
            Estate Facilities &amp; Infrastructure
          </p>
          <h2
            className="font-display text-4xl sm:text-5xl font-semibold text-[#1E1814] leading-[1.08] tracking-tight mb-4"
            style={{ textWrap: 'balance' }}
          >
            Every facility thoughtfully maintained for restoration and focus.
          </h2>
          <p className="text-base text-[#5C5046] leading-relaxed">
            Whether you are unplugging in the thermal plunge pool or leading a week-long creative
            sprint, every estate facility is included in your direct stay.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          {/* Left: Interactive 4-Domain Accordion / Selector */}
          <div className="lg:col-span-6 flex flex-col gap-3">
            {FACILITY_DOMAINS.map((domain) => {
              const isActive = domain.id === activeDomain.id;
              return (
                <div
                  key={domain.id}
                  className={`rounded-xl border transition-all duration-200 ${
                    isActive
                      ? 'bg-[#ECE5D8] border-[#B8472A] shadow-xs'
                      : 'bg-[#ECE5D8]/45 border-[#D5C9B6] hover:bg-[#ECE5D8]/85'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setActiveDomainId(domain.id)}
                    aria-expanded={isActive}
                    className="w-full text-left p-5 sm:p-6 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-[#B8472A]"
                  >
                    <div className="flex items-baseline justify-between gap-4">
                      <div className="flex items-baseline gap-3">
                        <span className="text-xs font-semibold text-[#B8472A] tabular-nums">
                          {domain.index}.
                        </span>
                        <h3 className="font-display text-2xl sm:text-[28px] font-semibold text-[#1E1814]">
                          {domain.title}
                        </h3>
                      </div>
                      <span
                        className={`text-xs font-semibold whitespace-nowrap ${
                          isActive ? 'text-[#B8472A]' : 'text-[#5C5046]'
                        }`}
                      >
                        {isActive ? 'Viewing' : 'Inspect'}
                      </span>
                    </div>
                    <p className="text-sm text-[#5C5046] mt-2 leading-relaxed">{domain.summary}</p>
                  </button>

                  <AnimatePresence initial={false}>
                    {isActive && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                        className="overflow-hidden"
                      >
                        <div className="px-5 sm:px-6 pb-6 pt-3 border-t border-[#D5C9B6]/80">
                          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {domain.items.map((item) => (
                              <div key={item.name}>
                                <dt className="text-sm font-semibold text-[#1E1814]">
                                  {item.name}
                                </dt>
                                <dd className="text-xs text-[#5C5046] mt-0.5 leading-relaxed">
                                  {item.detail}
                                </dd>
                              </div>
                            ))}
                          </dl>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

          {/* Right: Synchronized Architectural Facility Photo */}
          <div className="lg:col-span-6 flex flex-col justify-between gap-6">
            <div className="relative flex-1 min-h-[340px] sm:min-h-[420px] rounded-xl overflow-hidden border border-[#D5C9B6] bg-[#ECE5D8]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeDomain.id}
                  initial={{ opacity: 0.35, scale: 1.01 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0.35 }}
                  transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
                  className="w-full h-full"
                >
                  <ResilientImage
                    src={activeDomain.image.src}
                    alt={activeDomain.image.alt}
                    fallbackTitle={activeDomain.title}
                    className="w-full h-full object-cover"
                  />
                </motion.div>
              </AnimatePresence>

              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6 text-white">
                <p className="text-xs font-medium text-[#F3B19D] mb-1">
                  {activeDomain.index}. {activeDomain.image.label}
                </p>
                <p className="font-display text-2xl sm:text-[26px] font-medium leading-snug">
                  {activeDomain.image.caption}
                </p>
              </div>
            </div>

            <div className="bg-[#ECE5D8] border border-[#CBBCA6] rounded-xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-[#1E1814]">
                  All facilities are complimentary with every direct reservation.
                </p>
                <p className="text-xs text-[#5C5046] mt-0.5">
                  No resort fees, parking charges, or thermal pool surcharges.
                </p>
              </div>
              <button
                type="button"
                onClick={onReserveClick}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-[#B8472A] hover:bg-[#96361D] active:scale-[0.98] rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer"
              >
                <span>Reserve With Full Access</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

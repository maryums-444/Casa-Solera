import { motion } from 'motion/react';
import { Check, Plus } from 'lucide-react';
import { EXPERIENCE_ADDONS, STAY_PLANS } from '../data/propertyData';

interface PlansAndPricingSectionProps {
  activePlanId: string;
  selectedAddOns: string[];
  onSelectPlan: (planId: string) => void;
  onToggleAddOn: (addonId: string) => void;
}

export function PlansAndPricingSection({
  activePlanId,
  selectedAddOns,
  onSelectPlan,
  onToggleAddOn,
}: PlansAndPricingSectionProps) {
  return (
    <section id="plans" className="py-16 sm:py-24 border-b border-[#D5C9B6]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="max-w-2xl mb-12">
          <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-2">
            Stay Plans &amp; Curated Experiences
          </p>
          <h2
            className="font-display text-4xl sm:text-5xl font-semibold text-[#1E1814] leading-[1.08] tracking-tight mb-4"
            style={{ textWrap: 'balance' }}
          >
            Transparent plans designed around the length of your stay.
          </h2>
          <p className="text-base text-[#5C5046] leading-relaxed">
            Longer stays unlock deeper direct-rate reductions alongside weekly organic farm boxes,
            linen refreshes, and local studio access.
          </p>
        </div>

        {/* 3 Stay Plan Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-14">
          {STAY_PLANS.map((plan, idx) => {
            const isActive = activePlanId === plan.id;
            return (
              <motion.article
                key={plan.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.4, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
                className={`rounded-xl border p-6 sm:p-7 flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 ${
                  isActive
                    ? 'bg-[#ECE5D8] border-[#B8472A] shadow-sm'
                    : 'bg-[#ECE5D8]/55 border-[#D5C9B6] hover:border-[#C2B097]'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between gap-3 mb-3">
                    <span className="text-xs font-semibold text-[#B8472A] tabular-nums">
                      {plan.nightsLabel}
                    </span>
                    <span className="text-xs font-medium text-[#5C5046] tabular-nums">
                      {plan.discountPercent > 0 ? `${plan.discountPercent}% Off Direct` : '0% Fee'}
                    </span>
                  </div>

                  <h3 className="font-display text-3xl font-semibold text-[#1E1814] mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-xs font-semibold text-[#5C5046] mb-4">{plan.badgeText}</p>
                  <p className="text-sm text-[#5C5046] leading-relaxed mb-6">{plan.description}</p>

                  <ul className="space-y-2.5 pt-5 border-t border-[#D5C9B6] mb-6">
                    {plan.perks.map((perk) => (
                      <li key={perk} className="flex items-start gap-2.5 text-sm text-[#1E1814]">
                        <Check
                          className="w-4 h-4 text-[#B8472A] shrink-0 mt-0.5"
                          aria-hidden="true"
                        />
                        <span>{perk}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 border-t border-[#D5C9B6]">
                  <p className="text-xs text-[#5C5046] mb-4">Ideal for: {plan.idealFor}</p>
                  <button
                    type="button"
                    onClick={() => onSelectPlan(plan.id)}
                    className={`w-full py-3 px-4 text-sm font-medium rounded-lg transition-all duration-150 active:scale-[0.98] cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B8472A] ${
                      isActive
                        ? 'bg-[#241E1A] text-white hover:bg-[#3A312B]'
                        : 'bg-[#B8472A] text-white hover:bg-[#96361D]'
                    }`}
                  >
                    {isActive ? 'Active Plan · Go to Form' : `Choose ${plan.name}`}
                  </button>
                </div>
              </motion.article>
            );
          })}
        </div>

        {/* Optional Curated Experiences Add-On Selector */}
        <div className="bg-[#ECE5D8]/75 border border-[#CBBCA6] rounded-xl p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
            <div>
              <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-1">
                Optional In-Residence Experiences
              </p>
              <h3 className="font-display text-2xl sm:text-3xl font-semibold text-[#1E1814]">
                Enhance your itinerary at local partner rates.
              </h3>
            </div>
            <span className="text-xs font-medium text-[#5C5046] tabular-nums">
              {selectedAddOns.length} selected for your quote
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {EXPERIENCE_ADDONS.map((addon) => {
              const checked = selectedAddOns.includes(addon.id);
              return (
                <button
                  key={addon.id}
                  type="button"
                  onClick={() => onToggleAddOn(addon.id)}
                  aria-pressed={checked}
                  className={`text-left p-5 rounded-lg border transition-all duration-150 flex items-start justify-between gap-4 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B8472A] ${
                    checked
                      ? 'bg-[#F6F2EB] border-[#B8472A] shadow-xs'
                      : 'bg-[#F6F2EB]/70 border-[#D5C9B6] hover:bg-[#F6F2EB]'
                  }`}
                >
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-sm font-semibold text-[#1E1814]">{addon.name}</span>
                      <span className="text-xs font-semibold text-[#B8472A] tabular-nums">
                        +${addon.price} {addon.unit}
                      </span>
                    </div>
                    <p className="text-xs text-[#5C5046] mt-1 leading-relaxed">
                      {addon.description}
                    </p>
                  </div>

                  <span
                    className={`w-7 h-7 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                      checked
                        ? 'bg-[#B8472A] border-[#B8472A] text-white'
                        : 'border-[#D5C9B6] text-[#5C5046]'
                    }`}
                  >
                    {checked ? (
                      <Check className="w-4 h-4" aria-hidden="true" />
                    ) : (
                      <Plus className="w-4 h-4" aria-hidden="true" />
                    )}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { DIRECT_BENEFITS, HERO_METRICS } from '../data/propertyData';

interface MotiveAndBenefitsSectionProps {
  onExploreSuites: () => void;
}

export function MotiveAndBenefitsSection({ onExploreSuites }: MotiveAndBenefitsSectionProps) {
  return (
    <section id="motive" className="py-16 sm:py-24 border-b border-[#D5C9B6]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        {/* Our Motive Narrative + Adjacent Quantitative Proof */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start mb-16"
        >
          <div className="lg:col-span-7">
            <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-3">
              Our Motive &amp; Hospitality Ethos
            </p>
            <h2
              className="font-display text-4xl sm:text-5xl font-semibold text-[#1E1814] leading-[1.08] tracking-tight mb-6"
              style={{ textWrap: 'balance' }}
            >
              Warm, personal hospitality without the hidden platform fees.
            </h2>
            <div className="space-y-4 text-base text-[#5C5046] leading-relaxed max-w-2xl">
              <p>
                Most vacation rentals are built for quick turnover, with impersonal check-ins,
                rigid 10:00 AM departures, and steep service surcharges. Casa Solera was created
                around a simpler idea: giving guests the calm comfort of a small boutique hotel
                with the privacy of a private home.
              </p>
              <p>
                When you book directly with us instead of through third-party booking sites, those
                savings stay with your trip. You arrive to local Ojai olive oil and bakery loaves,
                enjoy full access to our heated saltwater pool, and never pay an extra marketplace
                commission.
              </p>
            </div>
          </div>

          {/* Adjacent Proof Strip */}
          <div className="lg:col-span-5 bg-[#ECE5D8] border border-[#CBBCA6] rounded-xl p-6 sm:p-8 shadow-xs">
            <h3 className="font-display text-2xl font-semibold text-[#1E1814] mb-5">
              Verified Direct-Stay Numbers
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-5">
              {HERO_METRICS.map((item) => (
                <div
                  key={item.label}
                  className="pb-4 border-b border-[#D5C9B6] last:border-b-0 last:pb-0 flex items-baseline justify-between gap-4"
                >
                  <span className="font-display text-2xl sm:text-3xl font-semibold text-[#B8472A] tabular-nums whitespace-nowrap">
                    {item.value}
                  </span>
                  <span className="text-xs sm:text-sm text-[#5C5046] text-right">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Unique Benefits of Booking Direct — Asymmetric Bento Layout */}
        <div className="mb-10 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-2">
              Why Guests Book Direct
            </p>
            <h3 className="font-display text-3xl sm:text-4xl font-semibold text-[#1E1814]">
              Four privileges reserved exclusively for direct bookings.
            </h3>
          </div>
          <button
            type="button"
            onClick={onExploreSuites}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#B8472A] hover:text-[#96361D] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <span>Compare Suites &amp; Rates</span>
            <ArrowRight className="w-4 h-4" aria-hidden="true" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {DIRECT_BENEFITS.map((benefit, idx) => (
            <motion.article
              key={benefit.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{ duration: 0.4, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className={`bg-[#ECE5D8]/80 hover:bg-[#ECE5D8] border border-[#D5C9B6] hover:border-[#B8472A]/60 rounded-xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 ${
                benefit.span === 'wide' ? 'md:col-span-2' : 'md:col-span-1'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-4 mb-4">
                  <span className="text-xs font-semibold text-[#B8472A] tabular-nums">
                    {benefit.index}.
                  </span>
                  <span className="text-xs font-medium text-[#5C5046] tabular-nums">
                    {benefit.metric}
                  </span>
                </div>
                <h4 className="font-display text-2xl sm:text-[28px] font-semibold text-[#1E1814] mb-2.5 leading-snug">
                  {benefit.title}
                </h4>
                <p className="text-sm sm:text-[15px] text-[#5C5046] leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

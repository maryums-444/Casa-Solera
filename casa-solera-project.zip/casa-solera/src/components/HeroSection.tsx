import { motion } from 'motion/react';
import { ArrowDown, ArrowRight, Calendar, Users } from 'lucide-react';
import { IMAGES, SUITES } from '../data/propertyData';
import { ResilientImage } from './ResilientImage';

interface HeroSectionProps {
  checkIn: string;
  checkOut: string;
  selectedSuiteId: string;
  guests: number;
  nights: number;
  estimatedTotal: number;
  directSavings: number;
  onCheckInChange: (value: string) => void;
  onCheckOutChange: (value: string) => void;
  onSuiteChange: (suiteId: string) => void;
  onGuestsChange: (guests: number) => void;
  onJumpToBooking: () => void;
}

export function HeroSection({
  checkIn,
  checkOut,
  selectedSuiteId,
  guests,
  nights,
  estimatedTotal,
  directSavings,
  onCheckInChange,
  onCheckOutChange,
  onSuiteChange,
  onGuestsChange,
  onJumpToBooking,
}: HeroSectionProps) {
  const activeSuite = SUITES.find((s) => s.id === selectedSuiteId) || SUITES[0];

  return (
    <section id="top" className="pb-12 sm:pb-16 border-b border-[#D5C9B6]">
      {/* Full-Bleed Hero Stage with Background Image & Measured Contrast Scrim */}
      <div className="relative w-full min-h-[540px] sm:min-h-[620px] lg:min-h-[680px] flex items-center justify-center overflow-hidden bg-[#241E1A]">
        {/* Animated Background Photography */}
        <motion.div
          initial={{ scale: 1.07, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.35, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0"
        >
          <ResilientImage
            src={IMAGES.heroCourtyard}
            alt="Casa Solera sunlit travertine courtyard with olive trees and terracotta planters at golden hour"
            loading="eager"
            fallbackTitle="Casa Solera Courtyard Villa"
            className="w-full h-full object-cover"
          />
        </motion.div>

        {/* Measured Contrast Scrim for High-Legibility Typography */}
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-b from-[#1A1410]/65 via-[#1A1410]/50 to-[#1A1410]/80"
        />

        {/* Centered Editorial Foreground Content */}
        <div className="relative z-10 max-w-4xl mx-auto px-5 sm:px-8 pt-12 pb-24 sm:pt-16 sm:pb-28 text-center">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="text-xs sm:text-sm font-semibold tracking-wider text-[#F5B9A6] mb-4"
          >
            <span>Ojai Valley, California</span>
            <span aria-hidden="true" className="mx-2 text-white/60">
              ·
            </span>
            <span>Direct Boutique Hotel Stay</span>
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
            className="font-display font-semibold text-[#FAF7F2] leading-[1.03] tracking-tight mb-6 drop-shadow-sm"
            style={{
              fontSize: 'clamp(2.75rem, 5.4vw, 4.75rem)',
              textWrap: 'balance',
            }}
          >
            Your private hillside stay in Ojai Valley.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="text-base sm:text-lg leading-relaxed text-[#EFE8DC] max-w-2xl mx-auto mb-8"
          >
            Welcome to Casa Solera. Enjoy private courtyard suites, a heated saltwater pool, and
            fresh local breakfast provisions every morning. Book directly with our hosts to skip
            14% platform fees and enjoy a relaxed 2:00 PM checkout.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.48, delay: 0.34, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-wrap items-center justify-center gap-4"
          >
            <button
              type="button"
              onClick={onJumpToBooking}
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-semibold text-white bg-[#B8472A] hover:bg-[#D15435] active:scale-[0.98] rounded-lg shadow-md transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <span>Reserve Direct &amp; Save 14%</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </button>

            <a
              href="#suites"
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-medium text-[#FAF7F2] border border-white/35 bg-[#1E1814]/45 hover:bg-[#1E1814]/70 backdrop-blur-sm rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <span>Explore Suites</span>
              <ArrowDown className="w-4 h-4 text-[#F5B9A6]" aria-hidden="true" />
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.45 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-x-5 gap-y-1.5 text-xs font-medium text-[#E5DDD0]"
          >
            <span>3 Private Suites &amp; Full Estate Buyout</span>
            <span aria-hidden="true" className="text-[#F5B9A6]">
              ·
            </span>
            <span>88°F Saltwater Plunge Pool</span>
            <span aria-hidden="true" className="text-[#F5B9A6]">
              ·
            </span>
            <span>Direct Rates from $365 / night</span>
          </motion.div>
        </div>
      </div>

      {/* Overlapping Floating 4-Column Quick Availability & Direct Quote Bar */}
      <div className="max-w-7xl mx-auto px-5 sm:px-8 -mt-12 sm:-mt-14 relative z-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="bg-[#ECE5D8] border border-[#CBBCA6] rounded-xl p-4 sm:p-6 shadow-lg"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-4 items-end">
            <div className="lg:col-span-3">
              <label
                htmlFor="hero-checkin"
                className="block text-xs font-medium text-[#5C5046] mb-1.5"
              >
                Check-In Date
              </label>
              <div className="relative">
                <Calendar
                  className="w-4 h-4 text-[#B8472A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="hero-checkin"
                  type="date"
                  value={checkIn}
                  onChange={(e) => onCheckInChange(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums focus:outline-none focus:border-[#B8472A] transition-colors"
                />
              </div>
            </div>

            <div className="lg:col-span-3">
              <label
                htmlFor="hero-checkout"
                className="block text-xs font-medium text-[#5C5046] mb-1.5"
              >
                Check-Out Date
              </label>
              <div className="relative">
                <Calendar
                  className="w-4 h-4 text-[#B8472A] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  id="hero-checkout"
                  type="date"
                  value={checkOut}
                  onChange={(e) => onCheckOutChange(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums focus:outline-none focus:border-[#B8472A] transition-colors"
                />
              </div>
            </div>

            <div className="lg:col-span-3">
              <label
                htmlFor="hero-suite"
                className="block text-xs font-medium text-[#5C5046] mb-1.5"
              >
                Suite Selection
              </label>
              <select
                id="hero-suite"
                value={selectedSuiteId}
                onChange={(e) => onSuiteChange(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] focus:outline-none focus:border-[#B8472A] transition-colors"
              >
                {SUITES.map((suite) => (
                  <option key={suite.id} value={suite.id}>
                    {suite.name} (${suite.nightlyRate}/nt)
                  </option>
                ))}
              </select>
            </div>

            <div className="lg:col-span-1">
              <label
                htmlFor="hero-guests"
                className="block text-xs font-medium text-[#5C5046] mb-1.5"
              >
                Guests
              </label>
              <div className="relative">
                <Users
                  className="w-4 h-4 text-[#5C5046] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <select
                  id="hero-guests"
                  value={guests}
                  onChange={(e) => onGuestsChange(Number(e.target.value))}
                  className="w-full pl-8 pr-2 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums focus:outline-none focus:border-[#B8472A] transition-colors"
                >
                  {Array.from({ length: activeSuite.maxGuests }, (_, i) => i + 1).map((num) => (
                    <option key={num} value={num}>
                      {num}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="lg:col-span-2 flex flex-col items-stretch">
              <button
                type="button"
                onClick={onJumpToBooking}
                className="w-full px-4 py-2.5 text-sm font-semibold text-white bg-[#B8472A] hover:bg-[#96361D] active:scale-[0.98] rounded-lg transition-all duration-150 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B8472A]"
              >
                Lock Direct Rate
              </button>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-[#D5C9B6] flex flex-wrap items-center justify-between gap-2 text-xs text-[#5C5046]">
            <span>
              Estimate for <strong className="text-[#1E1814]">{activeSuite.name}</strong> ·{' '}
              <span className="tabular-nums">{nights} nights</span>
            </span>
            <span className="tabular-nums">
              Direct total:{' '}
              <strong className="text-[#1E1814] text-sm">${estimatedTotal.toLocaleString()}</strong>{' '}
              <span className="text-[#B8472A] font-semibold">
                (Saves ${directSavings.toLocaleString()} vs. listing platforms)
              </span>
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

import { FormEvent, useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, ArrowRight } from 'lucide-react';
import {
  EXPERIENCE_ADDONS,
  GUEST_REVIEWS,
  STAY_PLANS,
  SUITES,
} from '../data/propertyData';

interface TestimonialsAndBookingSectionProps {
  checkIn: string;
  checkOut: string;
  selectedSuiteId: string;
  guests: number;
  nights: number;
  selectedAddOns: string[];
  formHighlightKey: number;
  onCheckInChange: (value: string) => void;
  onCheckOutChange: (value: string) => void;
  onSuiteChange: (suiteId: string) => void;
  onGuestsChange: (guests: number) => void;
  onToggleAddOn: (addonId: string) => void;
}

interface BookingErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  dates?: string;
}

export function TestimonialsAndBookingSection({
  checkIn,
  checkOut,
  selectedSuiteId,
  guests,
  nights,
  selectedAddOns,
  formHighlightKey,
  onCheckInChange,
  onCheckOutChange,
  onSuiteChange,
  onGuestsChange,
  onToggleAddOn,
}: TestimonialsAndBookingSectionProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<BookingErrors>({});
  const [confirmationRef, setConfirmationRef] = useState<string | null>(null);

  const activeSuite = SUITES.find((s) => s.id === selectedSuiteId) || SUITES[0];
  const activePlan =
    nights >= 14 ? STAY_PLANS[2] : nights >= 7 ? STAY_PLANS[1] : STAY_PLANS[0];

  const baseRoomSubtotal = activeSuite.nightlyRate * nights;
  const planDiscountAmount = Math.round(baseRoomSubtotal * (activePlan.discountPercent / 100));
  const discountedRoomTotal = baseRoomSubtotal - planDiscountAmount;
  const addOnsTotal = EXPERIENCE_ADDONS.filter((a) => selectedAddOns.includes(a.id)).reduce(
    (sum, item) => sum + item.price,
    0
  );
  const finalTotal = discountedRoomTotal + addOnsTotal;
  const platformComparisonTotal = Math.round(activeSuite.platformRate * nights + addOnsTotal);
  const totalSavedDirect = Math.max(0, platformComparisonTotal - finalTotal);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const nextErrors: BookingErrors = {};

    if (!fullName.trim() || fullName.trim().length < 2) {
      nextErrors.fullName = 'Please enter your full name.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      nextErrors.email = 'Please enter a valid email address.';
    }
    if (!/^[+\d\s().-]{7,}$/.test(phone.trim())) {
      nextErrors.phone = 'Please provide a valid contact phone number.';
    }
    if (nights < 2) {
      nextErrors.dates = 'Minimum direct stay is 2 nights.';
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    setErrors({});
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    setConfirmationRef(`CS-2026-${randomDigits}`);
  };

  return (
    <section id="booking" className="py-16 sm:py-24 border-b border-[#D5C9B6]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          {/* Left Column: Attributable Guest Reviews Adjacent to Conversion */}
          <div className="lg:col-span-5">
            <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-2">
              Guest Notes &amp; Direct Stays
            </p>
            <h2
              className="font-display text-4xl sm:text-[42px] font-semibold text-[#1E1814] leading-[1.08] tracking-tight mb-4"
              style={{ textWrap: 'balance' }}
            >
              Why returning guests never go back to booking platforms.
            </h2>
            <p className="text-sm sm:text-base text-[#5C5046] leading-relaxed mb-8">
              Every reservation is personally hosted by our Ojai stewards with zero call centers,
              no hidden cleaning surcharges, and immediate response before arrival.
            </p>

            <div className="space-y-5">
              {GUEST_REVIEWS.map((review, idx) => (
                <motion.blockquote
                  key={review.id}
                  initial={{ opacity: 0, y: 14 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.15 }}
                  transition={{ duration: 0.4, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
                  className="bg-[#ECE5D8]/75 border border-[#D5C9B6] rounded-xl p-6"
                >
                  <p className="text-sm text-[#1E1814] leading-relaxed mb-4">“{review.quote}”</p>
                  <footer className="pt-3 border-t border-[#D5C9B6] flex flex-col gap-0.5">
                    <span className="text-sm font-semibold text-[#1E1814]">{review.name}</span>
                    <span className="text-xs text-[#5C5046]">
                      {review.role} · {review.stayContext}
                    </span>
                  </footer>
                </motion.blockquote>
              ))}
            </div>
          </div>

          {/* Right Column: Interactive Direct Reservation & Instant Quote Engine */}
          <div id="booking-form" className="lg:col-span-7 scroll-mt-24">
            <motion.div
              key={formHighlightKey}
              initial={formHighlightKey > 0 ? { scale: 0.99 } : false}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className={`bg-[#ECE5D8] border rounded-xl p-6 sm:p-8 lg:p-10 transition-colors duration-300 ${
                formHighlightKey > 0 ? 'border-[#B8472A] shadow-sm' : 'border-[#CBBCA6]'
              }`}
            >
              {confirmationRef ? (
                <div className="py-6">
                  <div className="inline-flex items-center gap-2 text-sm font-semibold text-[#B8472A] mb-3">
                    <CheckCircle2 className="w-5 h-5" aria-hidden="true" />
                    <span>Direct Reservation Request Confirmed</span>
                  </div>
                  <h3 className="font-display text-3xl sm:text-4xl font-semibold text-[#1E1814] mb-3">
                    We look forward to welcoming you, {fullName}.
                  </h3>
                  <p className="text-sm sm:text-base text-[#5C5046] leading-relaxed mb-6">
                    Your direct reservation hold has been registered with zero platform fees. Our
                    Ojai host has sent your itinerary and arrival door-code instructions to{' '}
                    <strong className="text-[#1E1814]">{email}</strong>.
                  </p>

                  <dl className="bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg p-5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm mb-6">
                    <div>
                      <dt className="text-xs text-[#5C5046]">Reference Code</dt>
                      <dd className="font-semibold text-[#1E1814] tabular-nums mt-0.5">
                        {confirmationRef}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs text-[#5C5046]">Selected Suite</dt>
                      <dd className="font-semibold text-[#1E1814] mt-0.5">{activeSuite.name}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-[#5C5046]">Dates</dt>
                      <dd className="font-semibold text-[#1E1814] tabular-nums mt-0.5">
                        {checkIn} to {checkOut} ({nights} nights)
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs text-[#5C5046]">Confirmed Direct Total</dt>
                      <dd className="font-semibold text-[#B8472A] tabular-nums mt-0.5">
                        ${finalTotal.toLocaleString()} (Saved ${totalSavedDirect.toLocaleString()})
                      </dd>
                    </div>
                  </dl>

                  <button
                    type="button"
                    onClick={() => setConfirmationRef(null)}
                    className="px-5 py-2.5 text-sm font-medium text-[#1E1814] border border-[#D5C9B6] bg-[#F6F2EB] hover:bg-[#E2D9C8] rounded-lg transition-colors cursor-pointer"
                  >
                    Modify Reservation Details
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate>
                  <div className="flex flex-wrap items-baseline justify-between gap-3 pb-6 border-b border-[#D5C9B6] mb-6">
                    <div>
                      <p className="text-xs font-semibold tracking-wide text-[#B8472A] mb-1">
                        Direct Booking Request
                      </p>
                      <h3 className="font-display text-3xl sm:text-4xl font-semibold text-[#1E1814]">
                        Reserve Your Direct Stay
                      </h3>
                    </div>
                    <span className="text-xs font-medium text-[#5C5046] tabular-nums">
                      0% service fee · 2:00 PM checkout
                    </span>
                  </div>

                  {/* Suite, Dates, Guests */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5">
                    <div className="sm:col-span-2">
                      <label
                        htmlFor="book-suite"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Residence / Suite
                      </label>
                      <select
                        id="book-suite"
                        value={selectedSuiteId}
                        onChange={(e) => onSuiteChange(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] focus:outline-none focus:border-[#B8472A] transition-colors"
                      >
                        {SUITES.map((suite) => (
                          <option key={suite.id} value={suite.id}>
                            {suite.name} (${suite.nightlyRate}/night · Max {suite.maxGuests} guests)
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="book-checkin"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Check-In Date
                      </label>
                      <input
                        id="book-checkin"
                        type="date"
                        value={checkIn}
                        onChange={(e) => onCheckInChange(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums focus:outline-none focus:border-[#B8472A] transition-colors"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="book-checkout"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Check-Out Date
                      </label>
                      <input
                        id="book-checkout"
                        type="date"
                        value={checkOut}
                        onChange={(e) => onCheckOutChange(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums focus:outline-none focus:border-[#B8472A] transition-colors"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="book-guests"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Guest Count
                      </label>
                      <select
                        id="book-guests"
                        value={guests}
                        onChange={(e) => onGuestsChange(Number(e.target.value))}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums focus:outline-none focus:border-[#B8472A] transition-colors"
                      >
                        {Array.from({ length: activeSuite.maxGuests }, (_, i) => i + 1).map(
                          (num) => (
                            <option key={num} value={num}>
                              {num} {num === 1 ? 'Guest' : 'Guests'}
                            </option>
                          )
                        )}
                      </select>
                    </div>

                    <div>
                      <span className="block text-xs font-medium text-[#5C5046] mb-1.5">
                        Auto-Applied Stay Plan
                      </span>
                      <div className="px-3.5 py-2.5 text-sm bg-[#F6F2EB]/75 border border-[#D5C9B6] rounded-lg text-[#1E1814] tabular-nums">
                        {activePlan.name} ({nights} nights)
                      </div>
                    </div>
                  </div>

                  {errors.dates && (
                    <p role="alert" className="text-xs font-medium text-[#B8472A] mb-4">
                      {errors.dates}
                    </p>
                  )}

                  {/* Quick Experience Add-On Checkboxes */}
                  <div className="mb-6">
                    <span className="block text-xs font-medium text-[#5C5046] mb-2">
                      Optional Experiences
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {EXPERIENCE_ADDONS.map((addon) => {
                        const checked = selectedAddOns.includes(addon.id);
                        return (
                          <label
                            key={addon.id}
                            className={`flex items-center justify-between gap-2 px-3 py-2 rounded-lg border text-xs cursor-pointer transition-colors ${
                              checked
                                ? 'bg-[#F6F2EB] border-[#B8472A] text-[#1E1814]'
                                : 'bg-[#F6F2EB]/55 border-[#D5C9B6] text-[#5C5046]'
                            }`}
                          >
                            <span className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() => onToggleAddOn(addon.id)}
                                className="accent-[#B8472A]"
                              />
                              <span className="font-medium">{addon.name}</span>
                            </span>
                            <span className="tabular-nums shrink-0">+${addon.price}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Guest Contact Inputs */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    <div className="sm:col-span-2">
                      <label
                        htmlFor="guest-name"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Full Name
                      </label>
                      <input
                        id="guest-name"
                        type="text"
                        placeholder="e.g. Elena Vance"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] placeholder:text-[#5C5046]/60 focus:outline-none focus:border-[#B8472A] transition-colors"
                      />
                      {errors.fullName && (
                        <p className="text-xs text-[#B8472A] mt-1">{errors.fullName}</p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="guest-email"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Email Address
                      </label>
                      <input
                        id="guest-email"
                        type="email"
                        placeholder="elena@studio.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] placeholder:text-[#5C5046]/60 focus:outline-none focus:border-[#B8472A] transition-colors"
                      />
                      {errors.email && (
                        <p className="text-xs text-[#B8472A] mt-1">{errors.email}</p>
                      )}
                    </div>

                    <div>
                      <label
                        htmlFor="guest-phone"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Phone Number
                      </label>
                      <input
                        id="guest-phone"
                        type="tel"
                        placeholder="+1 (805) 555-0148"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] placeholder:text-[#5C5046]/60 focus:outline-none focus:border-[#B8472A] transition-colors"
                      />
                      {errors.phone && (
                        <p className="text-xs text-[#B8472A] mt-1">{errors.phone}</p>
                      )}
                    </div>

                    <div className="sm:col-span-2">
                      <label
                        htmlFor="guest-notes"
                        className="block text-xs font-medium text-[#5C5046] mb-1.5"
                      >
                        Arrival Preferences or Dietary Notes (Optional)
                      </label>
                      <textarea
                        id="guest-notes"
                        rows={2}
                        placeholder="Preferred espresso milk, thermal pool evening slot, or early bag drop time..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-sm bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg text-[#1E1814] placeholder:text-[#5C5046]/60 focus:outline-none focus:border-[#B8472A] transition-colors"
                      />
                    </div>
                  </div>

                  {/* Transparent Price Ledger */}
                  <div className="bg-[#F6F2EB] border border-[#D5C9B6] rounded-lg p-5 mb-6 space-y-2.5 text-sm">
                    <div className="flex justify-between text-[#5C5046]">
                      <span>
                        {activeSuite.name} (${activeSuite.nightlyRate} × {nights} nights)
                      </span>
                      <span className="tabular-nums text-[#1E1814]">
                        ${baseRoomSubtotal.toLocaleString()}
                      </span>
                    </div>
                    {planDiscountAmount > 0 && (
                      <div className="flex justify-between text-[#B8472A]">
                        <span>
                          {activePlan.name} ({activePlan.discountPercent}% Stay Reduction)
                        </span>
                        <span className="tabular-nums">
                          -${planDiscountAmount.toLocaleString()}
                        </span>
                      </div>
                    )}
                    {addOnsTotal > 0 && (
                      <div className="flex justify-between text-[#5C5046]">
                        <span>Curated Experiences ({selectedAddOns.length})</span>
                        <span className="tabular-nums text-[#1E1814]">
                          +${addOnsTotal.toLocaleString()}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between text-[#5C5046]">
                      <span>Direct Booking Service Fee</span>
                      <span className="tabular-nums font-semibold text-[#1E1814]">$0</span>
                    </div>
                    <div className="pt-3 border-t border-[#D5C9B6] flex items-baseline justify-between">
                      <div>
                        <span className="font-semibold text-[#1E1814]">Estimated Direct Total</span>
                        <p className="text-xs font-medium text-[#B8472A] tabular-nums">
                          You save ${totalSavedDirect.toLocaleString()} vs. listing platforms
                        </p>
                      </div>
                      <span className="font-display text-3xl font-semibold text-[#1E1814] tabular-nums">
                        ${finalTotal.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 px-6 text-sm font-medium text-white bg-[#B8472A] hover:bg-[#96361D] active:scale-[0.99] rounded-lg shadow-xs transition-all duration-150 inline-flex items-center justify-center gap-2 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B8472A]"
                  >
                    <span>Confirm Direct Reservation Request</span>
                    <ArrowRight className="w-4 h-4" aria-hidden="true" />
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-[#ECE5D8]/60 py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-[#D5C9B6]">
          <div className="md:col-span-5">
            <a
              href="#top"
              className="font-display text-2xl font-semibold text-[#241E1A] inline-block mb-3"
            >
              Casa Solera
            </a>
            <p className="text-sm text-[#5E5247] leading-relaxed max-w-sm">
              An intimate travertine &amp; olive-grove sanctuary in Ojai Valley, California.
              Hosted directly by our architectural stewards for restorative, zero-fee stays.
            </p>
          </div>

          <div className="md:col-span-3 space-y-2 text-sm">
            <p className="text-xs font-medium text-[#A34229] mb-2">Estate Navigation</p>
            <ul className="space-y-2 text-[#5E5247]">
              <li>
                <a href="#motive" className="hover:text-[#241E1A] transition-colors">
                  Our Motive
                </a>
              </li>
              <li>
                <a href="#suites" className="hover:text-[#241E1A] transition-colors">
                  Suites &amp; Galleries
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#241E1A] transition-colors">
                  Facilities
                </a>
              </li>
              <li>
                <a href="#plans" className="hover:text-[#241E1A] transition-colors">
                  Stay Plans
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4 space-y-2 text-sm text-[#5E5247]">
            <p className="text-xs font-medium text-[#A34229] mb-2">Host &amp; Policies</p>
            <p>1420 Foothill Ridge Rd, Ojai, CA 93023</p>
            <p>Direct Steward Desk: stay@casasolera.example</p>
            <p className="tabular-nums">Check-In: 3:00 PM · Direct Late Checkout: 2:00 PM</p>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-[#5E5247]">
          <p>© 2026 Casa Solera Ojai. All rights reserved.</p>
          <p>Free cancellation up to 7 days prior on all direct stays.</p>
        </div>
      </div>
    </footer>
  );
}
